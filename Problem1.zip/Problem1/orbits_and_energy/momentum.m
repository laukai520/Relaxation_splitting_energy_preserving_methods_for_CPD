function l=momentum(x,v)
l=(v(2)*x(1)-v(1)*x(2))-(x(1).^2+x(2).^2)^1.5/3;

 