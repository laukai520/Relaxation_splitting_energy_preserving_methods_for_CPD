function [x, v] =BorisE1(h,x0,v0,t0,t_end)
% the explicit filter method (\Psi (hB)=tanch(hB/2))
num=round((t_end - t0)/h);

t = t0 + [0:num]'*h;
     NN=length(x0);
     MM=length(t);
     x=zeros(NN,MM);
     v=x;
 x(:,1)=x0;v(:,1)=v0;
 
BB0=-BB(x0,0);
[phi10, phi20] =coefvarphi1phi2(-h*BB0); % coefficient functions at t=0
v1o2=phi10*v0+h/2*phi20*ff(x0);  %starting value v_{1/2}
x1=x0+h*v1o2;                     % value x_{1}
for k = 1:num
      t0=t0+h;
      BB1=-BB(x1,t0);
   [~, psi1, ~,sigma1,e1,delta1]= coefE1(h*BB1);% coefficient functions at t=h
      E1=ff(x1);NL=h*delta1*E1;
   PA1=h/2*psi1*E1;
   v1o2p=v1o2+PA1;
   v3o2m=e1*v1o2p;
   v3o2=v3o2m+PA1; % value v_{3/2}
   x2=x1+h*v3o2;   % value x_{2}
v1=sigma1*(v3o2m+v1o2p)/2+NL;
 x(:,k+1)=x1;v(:,k+1)=v1;
   x1=x2;
   v1o2=v3o2;

end
