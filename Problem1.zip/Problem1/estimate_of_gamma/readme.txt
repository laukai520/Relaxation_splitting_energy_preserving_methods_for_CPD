Please run "estimategamma.m" directly, and it will return the figure 2(d)  in Problem 1 that records the convegence of $\gamma$ with respect to stepsize $h$ for the proposed relaxation methods.
