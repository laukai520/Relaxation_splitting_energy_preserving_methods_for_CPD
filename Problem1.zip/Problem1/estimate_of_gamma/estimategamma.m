clc
clear all
format long

%%%%%%%% initial velues
x0=[0;1;0];
v0=[0.1;0.01;0];
%%%%%%%%%% t0 and t_end
t0=0;
h=pi/20;
hh=h*[  1/2^5 1/2^6 1/2^7 1/2^8 1/2^9 1/2^10];
num=200;
t_end=h*num;

 for i=1:length(hh)
h=hh(i);

  [gamma1(i)] =LTS_RSV(h,x0,v0,t0,t_end);


[gamma2(i)] =SS_RSV(h,x0,v0,t0,t_end);


end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 figure
interval=1;
loglog(hh(1:interval:end),gamma1(1:interval:end),'b-o','Markersize',8, 'LineWidth',1)
 hold on
 loglog(hh(1:interval:end),gamma2(1:interval:end),'b-p','Markersize',8, 'LineWidth',1)
 p=2;
loglog(hh,(gamma2(1)*(1+0.8))/hh(1)^p.*hh.^p,'c-.', 'LineWidth',1)
grid on
set(gca,'Fontsize',19)
legend('LTS-RSV','SS-RSV','order 2','Location','southeast');
 xlabel('h');
 ylabel('|\gamma|');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


