function l=energy(x,v)
l=v'*v/2+0.01/(sqrt(x(1).^2+x(2).^2));
 