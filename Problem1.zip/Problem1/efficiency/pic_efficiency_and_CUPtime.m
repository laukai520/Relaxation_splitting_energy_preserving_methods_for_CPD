clc
clear all
format long
% plot the errors of x for different methods
%%%%%%%% initial velues
x0=[0;1;0];
v0=[0.1;0.01;0];
%%%%%%%%%% t0 and t_end
t0=0;
h=pi/20;
hh=h*[ 1/2^5 1/2^6 1/2^7 1/2^8 1/2^9 1/2^10];
num=200;
t_end=h*num;
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
yy0=[x0;v0];
[T,Y] = ode45(@f,[t0, t_end],yy0,options);[m,n]=size(Y);xexact=(Y(m:m,1:3))'; vexact=(Y(m:m,4:6))';
 for i=1:length(hh)
h=hh(i);
tic
  [x1,v1] =LTS_RSV(h,x0,v0,t0,t_end);
  time1(i)=toc;
err1(i)=norm(abs(x1-xexact))/norm(xexact)+norm(abs(v1-vexact))/norm(vexact);
tic
[x2,v2] =SS_RSV(h,x0,v0,t0,t_end);
time2(i)=toc;
err2(i)=norm(abs(x2-xexact))/norm(xexact)+norm(abs(v2-vexact))/norm(vexact);
tic
  [x3,v3] =LTS_SV(h,x0,v0,t0,t_end);
time3(i)=toc;
err3(i)=norm(abs(x3-xexact))/norm(xexact)+norm(abs(v3-vexact))/norm(vexact);
tic
  [x4,v4] =SS_SV(h,x0,v0,t0,t_end);
time4(i)=toc;
err4(i)=norm(abs(x4-xexact))/norm(xexact)+norm(abs(v4-vexact))/norm(vexact);

  tic
  [x5,v5] =LTS_AVF(t0,t_end,x0,v0,h);
time5(i)=toc;
err5(i)=norm(abs(x5-xexact))/norm(xexact)+norm(abs(v5-vexact))/norm(vexact);
 
  tic
    [x6,v6] =SS_AVF(t0,t_end,x0,v0,h);
time6(i)=toc;
err6(i)=norm(abs(x6-xexact))/norm(xexact)+norm(abs(v6-vexact))/norm(vexact);

 tic
    [x7,v7] =BorisE1(h,x0,v0,t0,t_end);
time7(i)=toc;
err7(i)=norm(abs(x7-xexact))/norm(xexact)+norm(abs(v7-vexact))/norm(vexact);

 
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 figure
interval=1;
loglog(hh(1:interval:end),err1(1:interval:end),'b-o','Markersize',8, 'LineWidth',1)
 hold on
 loglog(hh(1:interval:end),err2(1:interval:end),'b-p','Markersize',8, 'LineWidth',1)
 loglog(hh(1:interval:end),err3(1:interval:end),'r-*','Markersize',8, 'LineWidth',1)
 loglog(hh(1:interval:end),err4(1:interval:end),'r-s','Markersize',8, 'LineWidth',1)
 loglog(hh(1:interval:end),err5(1:interval:end),'r-<','Markersize',8, 'LineWidth',1)
 loglog(hh(1:interval:end),err6(1:interval:end),'r->','Markersize',8, 'LineWidth',1)
 loglog(hh(1:interval:end),err7(1:interval:end),'r-d','Markersize',8, 'LineWidth',1)
  p=1;
loglog(hh,hh.^p,'c-', 'LineWidth',1)
 p=2;
loglog(hh,(err2(1)*(1+0.8))/hh(1)^p.*hh.^p,'c-.', 'LineWidth',1) 
grid on
xlabel('h');
set(gca,'Fontsize',19)
legend('LTS-RSV','SS-RSV','LTS-SV','SS-SV','LTS-AVF','SS-AVF','EFBoris','order 1','order 2','Location','southeast');
ylabel('Solution error');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
semilogy(time1(1:interval:end),err1(1:interval:end),'b-o','Markersize',8, 'LineWidth',1)
 hold on
semilogy(time2(1:interval:end),err2(1:interval:end),'b-p','Markersize',8, 'LineWidth',1)
semilogy(time3(1:interval:end),err3(1:interval:end),'r-*','Markersize',8, 'LineWidth',1)
semilogy(time4(1:interval:end),err4(1:interval:end),'r-s','Markersize',8, 'LineWidth',1)
 semilogy(time5(1:interval:end),err5(1:interval:end),'r-<','Markersize',8, 'LineWidth',1)
semilogy(time6(1:interval:end),err6(1:interval:end),'r->','Markersize',8, 'LineWidth',1)
semilogy(time7(1:interval:end),err7(1:interval:end),'r-d','Markersize',8, 'LineWidth',1)
%   
grid on
xlabel('CPU time');
set(gca,'Fontsize',19)
legend('LTS-RSV','SS-RSV','LTS-SV','SS-SV','LTS-AVF','SS-AVF','EFBoris','Location','northeast');
ylabel('Solution error');

