function [xout, vout] =BorisI1(h,x0,v0,t0,t_end)
% the implicit filter method (\Psi (hB)=sinch^2(hB/2))
num=(t_end - t0)/h; II=eye(3);
    BB0=-BB(x0,t0);CBB0=BB0/(norm(BB0))^2;
   [isinch0,sisinch0,sinch0,ssinch0, psi0, phi0,sigma0,e0,delta0] = coefIMPone(h*BB0); % coefficient functions
    xx0=x0-CBB0*v0;BBX0=-BB(xx0,t0);
   % [phi0] = coefphi(h*BBX0);         % coefficient phi
    [invphi20] = coefinvphi2(h*BBX0);    
    barPhi0=invphi20*isinch0;
    UPp=sinch0-1/2*barPhi0*ssinch0;
    Psp=psi0-2*UPp*delta0;
   v1o2=UPp*v0+h/2*Psp*ff(x0);      %starting value v_{1/2}
   x1=x0+h*v1o2;                     % value x_{1}
for k = 1:num
      t0=t0+h;
      BB1=-BB(x1,t0);CBB1=BB1/(norm(BB1))^2;  
     % KK=h*norm(BB1);
      %(KK)/sin(KK)
      %(KK/2)/sin(KK/2)
     % (3*KK/2)/sin(3*KK/2)
     [isinch1,sisinch1,sinch1,ssinch1, psi1, phi1,sigma1,e1,delta1]= coefIMPone(h*BB1);% coefficient functions at t=h
     % psi1=\Psi; sigma1=\sigma; e1=exp(-x); delta1=\delta
      EE1=ff(x1);
      PA1=h/2*psi1*EE1;
      v1o2p=v1o2+PA1;   % \bar v^{1-1/2}_+
 %%%%%%%%%%%%%% begin fix point iteration for \bar v^{1+1/2}_- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%iteration initial value
     v3o2m0=e1*v1o2p;  % iteration initial value for \bar v^{1+1/2}_- 
    %%%%%%%%%%%%%%     the fist iteration for \bar v^{1+1/2}_-
     NL=h*delta1*EE1;
     v1=sigma1*(v3o2m0+v1o2p)/2+NL;
     xx1=x1-CBB1*v1;BBX1=-BB(xx1,t0);    %guiding center for \bar{x} at t=h
    [invphi21] = coefinvphi2(h*BBX1);    
    barPhi1=invphi21*sisinch1;
    v3o2m1=(II+1/2*barPhi1)\((II-1/2*barPhi1)*(v1o2p));                      % the fist iteration result for \bar v^{1+1/2}_-
    %%%%%%%%%%%%%%%%%%%%%%%  %% iteration 
   m=0;
   while norm(v3o2m0-v3o2m1)> 10^(-16)   && m<100
       v1=sigma1*(v3o2m1+v1o2p)/2+NL;
     xx1=x1-CBB1*v1;BBX1=-BB(xx1,t0);    % guiding center for \bar{x}  
    [invphi21] = coefinvphi2(h*BBX1);  
      barPhi1=invphi21*sisinch1;
     v3o2m2=(II+1/2*barPhi1)\((II-1/2*barPhi1)*(v1o2p));       % the second iteration result for \bar v^{1+1/2}_- 
     v3o2m0=v3o2m1;v3o2m1=v3o2m2;        % update  
   m=m+1;
   end
   
     v3o2m=v3o2m1;                         % \bar v^{1+1/2}_-
%%%%%%%%%%%%%%%%% end fix point iteration for \bar v^{1+1/2}_-  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
   v3o2=v3o2m+PA1; % value \bar v^{n+1/2}
   x2=x1+h*v3o2;   % value x_{2}
  %  if k==num-2
  %     xoutm1=x2;    % outvalue x_{n-1}
  %   end
    if num==1
       xout=x1;    % outvalue x_{n} 
    end
    if k==num-1
       xout=x2;    % outvalue x_{n}
       vvv1o2=v3o2;
    end
   x1=x2;
   v1o2=v3o2;
end
vout=sigma1*(v3o2m+v1o2p)/2+NL; % outvalue v_{n}
%vout=sigma1*(vvv1o2+v3o2)/2+NL; % outvalue v_{n}
%vout=sigma1*(x1-xoutm1)/(2*h)+NL; % outvalue v_{n}
