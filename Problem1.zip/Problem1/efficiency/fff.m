function y1=fff(t,x)
%%%E(x)
k=sqrt(x(1)^2+x(2)^2);
k=0.01/(k^3);

y1=[x(1)*k;  x(2)*k;  0];
y1=[x(4:6);y1];
