function y=ff(x)
%%%E(x)
k=sqrt(x(1)^2+x(2)^2);
k=0.01/(k^3);

y=[x(1)*k;  x(2)*k;  0];
