function fu = BB(x,t)
%the matrix \hat{B}(x,t)
b1=0;
b2=0;
b3=sqrt(x(1)^2+x(2)^2);
fu=[0 b3 -b2; -b3 0 b1; b2 -b1 0];
