function  [x1,v1]=LTS_RSV(h,x0,v0,t0,t_end)
num=(t_end - t0)/h;
c1=1/2;bb1=1/2;
a=x0;b=v0;energy0=energy(a,b);
for i = 1:num
x_half=x0;
BB1=h*BB(x0,t0);
%expBB=coefexp(-BB1);
v_half=coefexp(-BB1)*v0;
Y1 = x_half+h*c1*v_half ;
    dn=(ff(Y1));
    ddn=(bb1*dn);
 x1= x_half + h*v_half +h^2*ddn;
v1 = v_half + h*dn;
a0=h^2*(dn')*dn/2; b0=h*v1'*dn; c0=energy(x1,v1)-energy0;
if (dn')*dn==0
    gamma=0;
else
      r1=(-b0-sgn(b0)*sqrt(b0^2-4*a0*c0))/2;
    gamma=c0/r1;
end
v1= v1 +gamma* h*dn;
x0=x1;v0=v1;
end
