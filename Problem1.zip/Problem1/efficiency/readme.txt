Please run "pic_efficiency_and_CUPtime.m" directly, and it will return the figure 2(b) (c) in Problem 1 that records  the convergence and time consumption of different schemes.
