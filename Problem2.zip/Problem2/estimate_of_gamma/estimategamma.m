clc
clear all
format long
% plot the errors for different methods
x0=[1/3;1/4;1/2];
%v0_ini=[10;8;0.05]; %v01
v0=[2/5;2/3;1]; %v01

%%%%%%%%%% t0 and t_end
t0=0;
t_end=1;
hh=1/2^7*[1/2^1 1/2^2 1/2^3 1/2^4 1/2^5 1/2^6 1/2^7];

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global ep
ep=1/2^3; 
for kk=1:length(hh)
 h=hh(kk);                    
  [gamma1ep3(kk)] =LTS_RSV(h,x0,v0,t0,t_end);
[gamma2ep3(kk)] =SS_RSV(h,x0,v0,t0,t_end);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global ep
ep=1/2^6; 
for kk=1:length(hh)
 h=hh(kk);                    
  [gamma1ep6(kk)] =LTS_RSV(h,x0,v0,t0,t_end);
[gamma2ep6(kk)] =SS_RSV(h,x0,v0,t0,t_end);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global ep
ep=1/2^9; 
for kk=1:length(hh)
 h=hh(kk);                    
  [gamma1ep9(kk)] =LTS_RSV(h,x0,v0,t0,t_end);
[gamma2ep9(kk)] =SS_RSV(h,x0,v0,t0,t_end);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 figure
interval=1;
 loglog(hh(1:interval:end),gamma1ep3(1:interval:end),'b-o','Markersize',8, 'LineWidth',1)
 hold on
 loglog(hh(1:interval:end),gamma2ep3(1:interval:end),'b-p','Markersize',8, 'LineWidth',1)
 
 loglog(hh(1:interval:end),gamma1ep6(1:interval:end),'r->','Markersize',8, 'LineWidth',1)
 loglog(hh(1:interval:end),gamma2ep6(1:interval:end),'r-<','Markersize',8, 'LineWidth',1)
 
 loglog(hh(1:interval:end),gamma1ep9(1:interval:end),'m-s','Markersize',8, 'LineWidth',1)
 loglog(hh(1:interval:end),gamma2ep9(1:interval:end),'m-d','Markersize',8, 'LineWidth',1)
 p=2;
loglog(hh,(gamma2ep3(1)*(1+0.8))/hh(1)^p.*hh.^p,'c-.', 'LineWidth',1)
grid on
set(gca,'Fontsize',19)
legend({'LTS-RSV, $\varepsilon=1/2^3$','SS-RSV, $\varepsilon=1/2^3$',...
    'LTS-RSV, $\varepsilon=1/2^6$','SS-RSV, $\varepsilon=1/2^6$',...
    'LTS-RSV, $\varepsilon=1/2^9$','SS-RSV, $\varepsilon=1/2^9$',...
    'order 2'},   'Interpreter','latex','Location','southeast');
 xlabel('h');
 ylabel('|\gamma|');
 xlim([5e-5 1e-2])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


