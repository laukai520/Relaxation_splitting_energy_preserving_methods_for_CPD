
function  [x,v]=LTS_SV(h,x0,v0,t0,t_end)
%����ѭ���Ĵ���num

num=round((t_end - t0)/h);

t = t0 + [0:num]'*h;
     NN=length(x0);
     MM=length(t);
     x=zeros(NN,MM);
     v=x;
%��ֵ
x(:,1)=x0;v(:,1)=v0;

c1=1/2;bb1=1/2;b1=1;
    

for i = 1:num
x_half=x0;
BB1=h*BB(x0,t0);
expBB=coefexp(-BB1);
v_half=expBB*v0;
% t0=t0+h/2;
Y1 = x_half+h*c1*v_half ;
    dn=(b1*ff(Y1));
    ddn=(bb1*ff(Y1));
 x1= x_half + h*v_half +h^2*ddn;
v1 = v_half + h*dn;
% t0=t0+h/2;
x(:,i+1)=x1;v(:,i+1)=v1;
 t0=t0+h;
x0=x1;
v0=v1;
end
