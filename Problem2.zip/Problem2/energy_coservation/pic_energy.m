clc
clear all
format long
%%%%%%%% initial velues
x0=[1/3;1/4;1/2];
v0=[2/5;2/3;1]; %v01
%%%%%%%%%% t0 and t_end
t0=0;
t_end=100;
epval=[  1/2^7 1/2^8 1/2^9 ];
global ep
for kk=1:length(epval)
    ep=epval(kk); 
h=1/2^10; T=1*t_end;
num=(t_end - t0)/h;
t = t0 + [0:num]'*h;
 [x1,v1] =LTS_RSV(h,x0,v0,t0,t_end);
  [x2,v2] =SS_RSV(h,x0,v0,t0,t_end);
  [x3,v3] =LTS_SV(h,x0,v0,t0,t_end);
  [x4,v4] =SS_SV(h,x0,v0,t0,t_end);
  [x5,v5] =LTS_AVF(t0,t_end,x0,v0,h);
  [x6,v6] =SS_AVF(t0,t_end,x0,v0,h);
  [x7,v7] =BorisE1(h,x0,v0,t0,t_end);

   
H1=zeros(num+1,1);H2=H1;H3=H1;H4=H1;H5=H1;H6=H1;H7=H1;
for i=1:num+1
H1(i)=energy(x1(:,i),v1(:,i));
H2(i)=energy(x2(:,i),v2(:,i));
H3(i)=energy(x3(:,i),v3(:,i));
H4(i)=energy(x4(:,i),v4(:,i));
H5(i)=energy(x5(:,i),v5(:,i));
H6(i)=energy(x6(:,i),v6(:,i));
H7(i)=energy(x7(:,i),v7(:,i));

end
 err1=abs(H1-H1(1));
err2=abs(H2-H2(1));
err3=abs(H3-H3(1));
err4=abs(H4-H4(1));
err5=abs(H5-H5(1));
err6=abs(H6-H6(1));
err7=abs(H7-H7(1));

figure
interval=2000;
semilogy(t(1:interval:end),err1(1:interval:end),'b-o','Markersize',8, 'LineWidth',1)
 hold on
 semilogy(t(1:interval:end),err2(1:interval:end),'b-p','Markersize',8, 'LineWidth',1)
 semilogy(t(1:interval:end),err3(1:interval:end),'r-*','Markersize',8, 'LineWidth',1)
 semilogy(t(1:interval:end),err4(1:interval:end),'r-s','Markersize',8, 'LineWidth',1)
 semilogy(t(1:interval:end),err5(1:interval:end),'r-<','Markersize',8, 'LineWidth',1)
 semilogy(t(1:interval:end),err6(1:interval:end),'r->','Markersize',8, 'LineWidth',1)
 semilogy(t(1:interval:end),err7(1:interval:end),'r-d','Markersize',8, 'LineWidth',1)
%   
grid on
xlabel('t');
set(gca,'Fontsize',19)
legend('LTS-RSV','SS-RSV','LTS-SV','SS-SV','LTS-AVF','SS-AVF','EFBoris','Location','southwest');
ylabel('Energy error');
str=strcat('Energy conservation with $\epsilon=\frac{1}{2^{',num2str(kk+6));
str=strcat(str,'}}$');
title(str,'Interpreter','latex');
end
 