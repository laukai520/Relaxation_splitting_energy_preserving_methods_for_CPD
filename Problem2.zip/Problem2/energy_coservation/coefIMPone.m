function [isinchout,sisinchout,sinchout,ssinchout,psiout, phiout, sigmaout,eout,deltaout] = coefIMPone(BB)
%coefficient functions for the implicit filter method one-step form 
aqrtb=norm(BB);
BB2=BB^2; 
II=eye(3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
isinchout=II+(1-aqrtb*csc(aqrtb))/aqrtb^2*BB2;   %isinchout=1/sinch(hB);
sisinchout=aqrtb*csc(aqrtb)*BB;               %sisinchout=hB/sinch(hB);
sinchout=II+(aqrtb-sin(aqrtb))/aqrtb^3*BB2;   %sinchout=sinch(s);
ssinchout=(sin(aqrtb))/aqrtb*BB;              %ssinchout=sinch(hB)hB;
phiout=II+(aqrtb-2*tan(aqrtb/2))/aqrtb^3*BB2; %phiout=tanch(s/2); 
sigmaout=II+(1-aqrtb*csc(aqrtb))/aqrtb^2*BB2; %sigmaout=\sigma(s)=1/sinch(s);
eout=II-sin(aqrtb)/aqrtb*BB+(1-cos(aqrtb))/aqrtb^2*BB2; %eout=exp(-s)
psiout=phiout; %psiout=\Psi (s)=tanch(s/2);
deltaout=(aqrtb*csc(aqrtb)-1)/aqrtb^2*BB; %deltaout=(1-\sigma(s))/(s)

