function [x, v]=SS_AVF(t0,t_end,x0,v0,h)
num=round((t_end - t0)/h);

t = t0 + [0:num]'*h;
     NN=length(x0);
     MM=length(t);
     x=zeros(NN,MM);
     v=x;
a=(3-sqrt(3))/6;  b=(3+sqrt(3))/6;

 x(:,1)=x0;v(:,1)=v0;
for k = 1:num
 XX=x0;
 vv=h/2*BB(XX,t0); 
 VV=coefexp(-vv)*v0;   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    j=0;
       Q1=XX + h*VV + h^2/2*(ff(b*XX+a*XX)+ff(a*XX+b*XX))/2;
    while 1
      Y1=XX + h*VV + h^2/2*(ff(b*XX+a*Q1)+ff(a*XX+b*Q1))/2;
        if norm(Y1-Q1)< 10^(-15)
            break;
        end
        if j>10000
           % fprintf('The iteration   divergence: i=%8.0f \n',i)
            break;
        end
        Q1=Y1;
        j=j+1;      
    end
    x1=XX + h*VV + h^2/2*(ff(b*XX+a*Q1)+ff(a*XX+b*Q1))/2;
    v1=VV+h*(ff(b*XX+a*x1)+ff(a*XX+b*x1))/2;
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
 
 vv=h/2*BB(x1,t0); 
 v1=coefexp(-vv)*v1; 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 x(:,k+1)=x1;v(:,k+1)=v1;
 t0=t0+h;
x0=x1;
v0=v1;
end

