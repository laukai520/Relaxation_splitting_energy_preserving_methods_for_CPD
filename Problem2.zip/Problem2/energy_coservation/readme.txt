Please run "pic_orbits_and_energy.m" directly, and it will return  Figure 5 (a) (b) (c)  in Problem 2 that records energy errors for different splitting schemes  under different $\varepsilon$.
