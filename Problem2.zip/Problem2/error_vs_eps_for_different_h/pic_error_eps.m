clc
clear all
format long

x0_ini=[1/3;1/4;1/2];
v0_ini=[2/5;2/3;1]; %v01
    global ep
 x0=x0_ini; v0=v0_ini;
t0=0;
t_end=1;
m=0;
%%%%%%%%%% \epsilon  
epval=[ 1 1/2 1/2^2 1/2^3 1/2^4 1/2^5 1/2^6 1/2^7 1/2^8  1/2^9 1/2^10];
%%%%%%%%%% stepsizes
hh=[ 1/2^7  1/2^8 1/2^9]/2^m;

for i=1:length(hh)
    h=hh(i);
for kk=1:length(epval)
     ep=epval(kk); 
 [x1out{kk},v1out{kk}] = LTS_RSV(h,x0,v0,t0,t_end); 
 [x2out{kk},v2out{kk}] = SS_RSV(h,x0,v0,t0,t_end); 
  options = odeset('RelTol',1e-12,'AbsTol',1e-12);
  [T,Y] = ode45(@fff,[0 t_end],[x0_ini;v0_ini],options);
    [mm,n]=size(Y);
  xexact=(Y(mm:mm,1:3))';
  vexact=(Y(mm:mm,4:6))';
 vvexact=paf(xexact,vexact);
%%%%%%%%%% global errors of x and v
    vv1out{kk}=paf(x1out{kk},v1out{kk}); 
   err1(kk) = norm(abs(x1out{kk}-xexact))/norm(xexact)+norm(abs(vv1out{kk}-vvexact))/norm(vvexact); 
    vv2out{kk}=paf(x2out{kk},v2out{kk}); 
   err2(kk) = norm(abs(x2out{kk}-xexact))/norm(xexact)+norm(abs(vv2out{kk}-vvexact))/norm(vvexact); 

end
%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
loglog((epval),(err1),'r-*','MarkerSize',8,'LineWidth',1)
hold on
loglog((epval),(err2),'b-p','MarkerSize',8,'LineWidth',1)
str=strcat('$h=\frac{1}{2^{',num2str(i+6+m));
str=strcat(str,'}}$');
legend('LTS-RSV','SS-RSV','Location','southwest');
xlabel({'$\varepsilon$'},'Interpreter','latex');
ylabel({'$error$'},'Interpreter','latex');
title(str,'Interpreter','latex');
set(gca,'Fontsize',19)
box on
grid on
end
