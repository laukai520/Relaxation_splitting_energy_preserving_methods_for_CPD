
function  [x1,v1]=SS_SV(h,x0,v0,t0,t_end)
%����ѭ���Ĵ���num
num=(t_end - t0)/h;

%��ֵ
c1=1/2;bb1=1/2;b1=1;
for i = 1:num
x_half=x0;

v_half=coefexp(-h/2*BB(x0,t0))*v0;
% t0=t0+h/2;
Y1 = x_half+h*c1*v_half ;
    dn=(b1*ff(Y1));
        ddn=(bb1*dn);%ddn=(bb1*ff(Y1));
 x_half= x_half + h*v_half +h^2*ddn;
v_half = v_half + h*dn;

% t0=t0+h/2;
x1= x_half;
v1=coefexp(-h/2*BB(x_half,t0))*v_half;
 t0=t0+h;
x0=x1;
v0=v1;
end
