function fu = BB(x,t)
global ep
b1=1/ep*cos(ep*x(2))-x(1);
b2=1/ep*(1+sin(ep*x(3)));
b3=1/ep*cos(ep*x(1))+x(3);
fu=[0 b3 -b2; -b3 0 b1; b2 -b1 0];
