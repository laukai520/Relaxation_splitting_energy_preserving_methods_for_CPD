function dy = fff(t,q)
%the nonlinear function for ODE45
global ep
dy = zeros(6,1); 
SXX2=sqrt(q(1)^2+q(2)^2);
k=1/((SXX2^2)^(3/2)); 

bb1=1/ep*cos(ep*q(2))-q(1);
bb2=1/ep*(1+sin(ep*q(3)));
bb3=1/ep*cos(ep*q(1))+q(3);

dy(1) = q(4);
dy(2) = q(5);
dy(3) = q(6);
dy(4) = q(1)*k+bb3*q(5)-bb2*q(6);
dy(5) = q(2)*k-bb3*q(4)+bb1*q(6);
dy(6) = 0+bb2*q(4)-bb1*q(5);


 
 
