function x=sgn(b)
if b>0
    x=1;
elseif b==0
    x=0;
else
    x=-1;
end