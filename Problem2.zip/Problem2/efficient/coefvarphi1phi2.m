function [phi1out, phi2out] = coefvarphi1phi2(BB)
%coefficient functions for  varphi1  and varphi2
aqrtb=norm(BB);
BB2=BB^2; 
II=eye(3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
phi1out=II+(1-cos(aqrtb))/aqrtb^2*BB+(aqrtb-sin(aqrtb))/aqrtb^3*BB2;                %phi1out=varphi1
phi2out=II+2*(aqrtb-sin(aqrtb))/aqrtb^3*BB+(aqrtb^2-2+2*cos(aqrtb))/aqrtb^4*BB2;    %phi2out=varphi2

 
 