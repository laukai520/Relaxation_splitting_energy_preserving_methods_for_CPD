function y=f(t,xx)
x=xx(1:3);
v=xx(4:6);
y=[v;BB(x,0)*v+ff(x)];
