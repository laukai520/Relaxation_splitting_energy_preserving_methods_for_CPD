function fu = paf(q,v)
%the function E(x,t)
global ep
T1=(q(2)-q(3))/2;
T2=(q(1)+q(3))/2;
T3=(q(2)-q(1))/2;
b1=T1/ep;
b2=T2/ep;
b3=T3/ep;
BB=[b1;
   b2;
   b3];
BB=BB/norm(BB);
fu=dot(BB,v)*BB;

 