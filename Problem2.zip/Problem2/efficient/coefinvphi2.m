function [invphi2out] = coefinvphi2(BB)
%coefficient function  invphi2out(s)=sinch(s/2)^2; 
aqrtb=norm(BB);
BB2=BB^2; 
II=eye(3);
invphi2out=II+(-2+aqrtb^2+2*cos(aqrtb))/aqrtb^4*BB2; %invphi2out(s)=sinch(s/2)^2; 