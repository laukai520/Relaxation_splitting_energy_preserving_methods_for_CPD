function [eout] = coefexp(BB)
%coefficient function exp(-s)
aqrtb=norm(BB);
BB2=BB^2; 
II=eye(3);
eout=II-sin(aqrtb)/aqrtb*BB+(1-cos(aqrtb))/aqrtb^2*BB2; %eout=exp(-s)