function [sinchout,psiout, phiout, sigmaout,eout,deltaout] = coefE1(BB)
%coefficient functions for the explicit filter method   E1
%sinchout=sinch(s);psiout=\Psi (s)=tanch(s/2); phiout=psiout; 
%sigmaout=\sigma(s)=1/sinch(s);eout=exp(-s);deltaout=(\sigma(s)-1)/(s)
aqrtb=norm(BB);
BB2=BB^2; 
II=eye(3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
sinchout=II+(aqrtb-sin(aqrtb))/aqrtb^3*BB2;   %sinchout=sinch(s);
phiout=II+(aqrtb-2*tan(aqrtb/2))/aqrtb^3*BB2; %phiout=tanch(s/2); 
sigmaout=II+(1-aqrtb*csc(aqrtb))/aqrtb^2*BB2; %sigmaout=\sigma(s)=1/sinch(s);
eout=II-sin(aqrtb)/aqrtb*BB+(1-cos(aqrtb))/aqrtb^2*BB2; %eout=exp(-s)
psiout=phiout; %psiout=\Psi (s)=tanch(s/2);
deltaout=(aqrtb*csc(aqrtb)-1)/aqrtb^2*BB; %deltaout=(1-\sigma(s))/(s)
