clc
clear all
format long
% plot the errors of x for different methods
%%%%%%%% initial velues
x0=[1/3;1/4;1/2];
v0=[2/5;2/3;1]; %v01
%%%%%%%%%% t0 and t_end
t0=0;
t_end=5;

% epval=[  1/2^5 1/2^6 1/2^7 ]/8;
epval=[  1/2^7  1/2^8 1/2^9 ];
hh=[1/2^11 1/2^12 1/2^13 1/2^14];
% epval=[  1/2^5  ]/8;
global ep
for kk=1:length(epval)
    ep=epval(kk); 
time1=zeros(size(hh)); time2=time1;time3=time1;time4=time1;time5=time1;time6=time1;time7=time1;
err1=time1;err2=time1;err3=time1;err4=time1;err5=time1;err6=time1;err7=time1;
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
yy0=[x0;v0];
[T,Y] = ode45(@fff,[0:t_end],yy0,options);[m,n]=size(Y);xexact=(Y(m:m,1:3))'; vexact=(Y(m:m,4:6))';
vvexact=paf(xexact,vexact);
for i=1:length(hh)
h=hh(i);
tic
  [x1,v1] =LTS_RSV(h,x0,v0,t0,t_end);
time1(i)=toc;
vv1out=paf(x1,v1);  
err1(i) = norm(abs(x1-xexact))/norm(xexact)+norm(abs(vv1out-vvexact))/norm(vvexact); 
tic
[x2,v2] =SS_RSV(h,x0,v0,t0,t_end);
time2(i)=toc;
vv2out=paf(x2,v2);  
err2(i) = norm(abs(x2-xexact))/norm(xexact)+norm(abs(vv2out-vvexact))/norm(vvexact); 
tic
  [x3,v3] =LTS_SV(h,x0,v0,t0,t_end);
time3(i)=toc;
vv3out=paf(x3,v3);  
err3(i) = norm(abs(x3-xexact))/norm(xexact)+norm(abs(vv3out-vvexact))/norm(vvexact); 
tic
  [x4,v4] =SS_SV(h,x0,v0,t0,t_end);
time4(i)=toc;
vv4out=paf(x4,v4);  
err4(i) = norm(abs(x4-xexact))/norm(xexact)+norm(abs(vv4out-vvexact))/norm(vvexact); 

tic
[x5, v5]=LTS_AVF(t0,t_end,x0,v0,h);

time5(i)=toc;
vv5out=paf(x5,v5);  
err5(i) = norm(abs(x5-xexact))/norm(xexact)+norm(abs(vv5out-vvexact))/norm(vvexact); 

tic
[x6, v6]=SS_AVF(t0,t_end,x0,v0,h);

time6(i)=toc;
vv6out=paf(x6,v6);  
err6(i) = norm(abs(x6-xexact))/norm(xexact)+norm(abs(vv6out-vvexact))/norm(vvexact); 



tic
[x7, v7]=BorisE1(h,x0,v0,t0,t_end);
time7(i)=toc;
vv7out=paf(x7,v7);  
err7(i) = norm(abs(x7-xexact))/norm(xexact)+norm(abs(vv7out-vvexact))/norm(vvexact); 

end



interval=1;
figure
semilogy(time1(1:interval:end),err1(1:interval:end),'b-o','Markersize',8, 'LineWidth',1)
 hold on
semilogy(time2(1:interval:end),err2(1:interval:end),'b-p','Markersize',8, 'LineWidth',1)
semilogy(time3(1:interval:end),err3(1:interval:end),'r-*','Markersize',8, 'LineWidth',1)
semilogy(time4(1:interval:end),err4(1:interval:end),'r-s','Markersize',8, 'LineWidth',1)
 semilogy(time5(1:interval:end),err5(1:interval:end),'r-<','Markersize',8, 'LineWidth',1)
semilogy(time6(1:interval:end),err6(1:interval:end),'r->','Markersize',8, 'LineWidth',1)
semilogy(time7(1:interval:end),err7(1:interval:end),'r-d','Markersize',8, 'LineWidth',1)
%   
grid on
xlabel('CPU time');
set(gca,'Fontsize',19)
legend('LTS-RSV','SS-RSV','LTS-SV','SS-SV','LTS-AVF','SS-AVF','EFBoris','Location','northeast');
ylabel('Solution error');
str=strcat('Efficiency with $\epsilon=\frac{1}{2^{',num2str(kk+6));
str=strcat(str,'}}$');
title(str,'Interpreter','latex');
end
 