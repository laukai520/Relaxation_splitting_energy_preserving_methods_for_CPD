Please run "pic_CUPtime.m" directly, and it will return the figure 6(a) (b) in Problem 2 that records  CPU times against errors for different splitting schemes under different $\varepsilon$.
