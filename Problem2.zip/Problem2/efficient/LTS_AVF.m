function [xout, vout]=LTS_AVF(t0,t_end,x0,v0,h)
% splitting methods ENERGY-PRESERVING
num=(t_end - t0)/h;
a=(3-sqrt(3))/6;  b=(3+sqrt(3))/6;
 t0=0;
 
for k = 1:num
 XX=x0;
 v=h*BB(XX,t0); 
 VV=coefexp(-v)*v0;   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    j=0;
       Q1=XX + h*VV + h^2/2*(ff(b*XX+a*XX)+ff(a*XX+b*XX))/2;
    while 1
      Y1=XX + h*VV + h^2/2*(ff(b*XX+a*Q1)+ff(a*XX+b*Q1))/2;
        if norm(Y1-Q1)< 10^(-15)
            break;
        end
        if j>1000
            fprintf('The AAVF   divergence: k=%8.0f \n',k)
            break;
        end
        Q1=Y1;
        j=j+1;      
    end
    PP=(ff(b*XX+a*Q1)+ff(a*XX+b*Q1))/2;
    x1=XX + h*VV + h^2/2*PP;
    v1=VV+h*PP;
 x0=x1;v0=v1; t0=t0+h;
end
xout=x0;vout=v0;
