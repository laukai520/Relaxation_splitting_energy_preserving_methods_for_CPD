clc
clear all
format long
% plot the errors for different methods
x0_ini=[1/3;1/4;1/2];
%v0_ini=[10;8;0.05]; %v01
v0_ini=[2/5;2/3;1]; %v01

%%%%%%%%%% t0 and t_end
t_beg=0;
t_end=1;
hh=1/2^5*[1/2^1 1/2^2 1/2^3 1/2^4 1/2^5 1/2^6 1/2^7];
%%%%%%%%%% numerical solutions of different methods
 
 

global ep
ep=1/2^2; 
tic
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
  [T,Y] = ode45(@fff,[0:t_end],[x0_ini;v0_ini],options);[m,n]=size(Y);
  xexact=(Y(m:m,1:3))';
  vexact=(Y(m:m,4:6))';
for kk=1:length(hh)
 h=hh(kk);                    
[x1out{kk},v1out{kk}] = RSV2(h,x0_ini,v0_ini,t_beg,t_end); 
vv1out{kk}=paf(x1out{kk},v1out{kk});  vvexact=paf(xexact,vexact);
err3(kk) = norm(abs(v1out{kk}-vexact))/norm(abs(vexact));
end
toc
%%%%%%%%% reference exact solution
global ep
ep=1/2^3; 
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
  [T,Y] = ode45(@fff,[0:t_end],[x0_ini;v0_ini],options);[m,n]=size(Y);
  xexact=(Y(m:m,1:3))';
  vexact=(Y(m:m,4:6))';
for kk=1:length(hh)
 h=hh(kk);
[x1out{kk},v1out{kk}] = RSV2(h,x0_ini,v0_ini,t_beg,t_end); 
vv1out{kk}=paf(x1out{kk},v1out{kk});  vvexact=paf(xexact,vexact);
err4(kk) = norm(abs(v1out{kk}-vexact))/norm(abs(vexact)); 
end
 
global ep
ep=1/2^4; 
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
  [T,Y] = ode45(@fff,[0:t_end],[x0_ini;v0_ini],options);[m,n]=size(Y);
  xexact=(Y(m:m,1:3))';
  vexact=(Y(m:m,4:6))';
for kk=1:length(hh)
 h=hh(kk);
[x1out{kk},v1out{kk}] = RSV2(h,x0_ini,v0_ini,t_beg,t_end); 
vv1out{kk}=paf(x1out{kk},v1out{kk});  vvexact=paf(xexact,vexact);
err5(kk) = norm(abs(v1out{kk}-vexact))/norm(abs(vexact)); 
end
%%%%%%%%% reference exact solution
global ep
ep=1/2^5; 
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
  [T,Y] = ode45(@fff,[0:t_end],[x0_ini;v0_ini],options);[m,n]=size(Y);
  xexact=(Y(m:m,1:3))';
  vexact=(Y(m:m,4:6))';
for kk=1:length(hh)
 h=hh(kk);
[x1out{kk},v1out{kk}] = RSV2(h,x0_ini,v0_ini,t_beg,t_end); 
vv1out{kk}=paf(x1out{kk},v1out{kk});  vvexact=paf(xexact,vexact);
err6(kk) = norm(abs(v1out{kk}-vexact))/norm(abs(vexact));
end

global ep
ep=1/2^6; 
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
  [T,Y] = ode45(@fff,[0:t_end],[x0_ini;v0_ini],options);[m,n]=size(Y);
  xexact=(Y(m:m,1:3))';
  vexact=(Y(m:m,4:6))';
for kk=1:length(hh)
 h=hh(kk);
[x1out{kk},v1out{kk}] = RSV2(h,x0_ini,v0_ini,t_beg,t_end); 
vv1out{kk}=paf(x1out{kk},v1out{kk});  vvexact=paf(xexact,vexact);
err7(kk) = norm(abs(v1out{kk}-vexact))/norm(abs(vexact)); 
end
%%%%%%%%% reference exact solution
global ep
ep=1/2^7; 
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
  [T,Y] = ode45(@fff,[0 t_end],[x0_ini;v0_ini],options);[m,n]=size(Y);
  xexact=(Y(m:m,1:3))';
  vexact=(Y(m:m,4:6))';
for kk=1:length(hh)
 h=hh(kk);
[x1out{kk},v1out{kk}] = RSV2(h,x0_ini,v0_ini,t_beg,t_end); 
vv1out{kk}=paf(x1out{kk},v1out{kk});  vvexact=paf(xexact,vexact);
err8(kk) = norm(abs(v1out{kk}-vexact))/norm(abs(vexact));
end

%%%%%%%%%% show the figure of x
set(gca,'Fontsize',16)
hold on
%plot(log10(hh),log10(err1),'b-*','MarkerSize',12)
%plot(log10(hh),log10(err2),'b-*','MarkerSize',12,'LineWidth',1)
plot(log10(hh),log10(err3),'g-^','MarkerSize',12)
plot(log10(hh),log10(err4),'r-p','MarkerSize',12,'LineWidth',1)
plot(log10(hh),log10(err5),'m-d','MarkerSize',12)
plot(log10(hh),log10(err6),'g-s','MarkerSize',12,'LineWidth',1)
plot(log10(hh),log10(err7),'b->','MarkerSize',12)
plot(log10(hh),log10(err8),'c-<','MarkerSize',12,'LineWidth',1)

%plot(log10(epval),2*log10(epval),'k:.','MarkerSize',18)
plot(log10(hh),log10(hh),'k-.','MarkerSize',12)
%legend({'$\epsilon=1/2$','$\epsilon=1/2^2$','$\epsilon=1/2^3$','$\epsilon=1/2^{4}$','$\epsilon=1/2^{5}$','$\epsilon=1/2^{6}$','$\epsilon=1/2^{7}$'},'Interpreter','latex');
legend({'$\varepsilon=1/2^2$','$\varepsilon=1/2^{3}$','$\varepsilon=1/2^{4}$','$\varepsilon=1/2^5$','$\varepsilon=1/2^6$','$\varepsilon=1/2^{7}$'},'Interpreter','latex');
xlabel({'$log_{10}(h)$'},'Interpreter','latex');
ylabel({'$log_{10}(errvper)$'},'Interpreter','latex');
title('RSV2')
box on
%axis([-5 -1 -12 0])
%axis([-4 -1 -10 1])
