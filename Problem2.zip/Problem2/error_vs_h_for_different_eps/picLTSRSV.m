clc
clear all
format long
x0_ini=[1/3;1/4;1/2];

v0_ini=[2/5;2/3;1]; %v01

%%%%%%%%%% t0 and t_end
t_beg=0;
t_end=1;
hh=1/2^7*[1/2^1 1/2^2 1/2^3 1/2^4 1/2^5 1/2^6 1/2^7];
%%%%%%%%%% numerical solutions of different methods
 
 

global ep
ep=1/2^2; 
tic
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
  [T,Y] = ode45(@fff,[0:t_end],[x0_ini;v0_ini],options);[m,n]=size(Y);
  xexact=(Y(m:m,1:3))';
  vexact=(Y(m:m,4:6))';
for kk=1:length(hh)
 h=hh(kk);                    
[x1out{kk},v1out{kk}] = LTS_RSV(h,x0_ini,v0_ini,t_beg,t_end); 
vv1out{kk}=paf(x1out{kk},v1out{kk});  vvexact=paf(xexact,vexact);
err3(kk) = norm(abs(x1out{kk}-xexact))/norm(xexact)+norm(abs(vv1out{kk}-vvexact))/norm(vvexact); 
end
toc
%%%%%%%%% reference exact solution
global ep
ep=1/2^4; 
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
  [T,Y] = ode45(@fff,[0:t_end],[x0_ini;v0_ini],options);[m,n]=size(Y);
  xexact=(Y(m:m,1:3))';
  vexact=(Y(m:m,4:6))';
for kk=1:length(hh)
 h=hh(kk);
[x1out{kk},v1out{kk}] = LTS_RSV(h,x0_ini,v0_ini,t_beg,t_end); 
vv1out{kk}=paf(x1out{kk},v1out{kk});  vvexact=paf(xexact,vexact);
err4(kk) = norm(abs(x1out{kk}-xexact))/norm(xexact)+norm(abs(vv1out{kk}-vvexact))/norm(vvexact); 
end
 
global ep
ep=1/2^6; 
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
  [T,Y] = ode45(@fff,[0:t_end],[x0_ini;v0_ini],options);[m,n]=size(Y);
  xexact=(Y(m:m,1:3))';
  vexact=(Y(m:m,4:6))';
for kk=1:length(hh)
 h=hh(kk);
[x1out{kk},v1out{kk}] = LTS_RSV(h,x0_ini,v0_ini,t_beg,t_end); 
vv1out{kk}=paf(x1out{kk},v1out{kk});  vvexact=paf(xexact,vexact);
err5(kk) = norm(abs(x1out{kk}-xexact))/norm(xexact)+norm(abs(vv1out{kk}-vvexact))/norm(vvexact); 
end
%%%%%%%%% reference exact solution
global ep
ep=1/2^8; 
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
  [T,Y] = ode45(@fff,[0:t_end],[x0_ini;v0_ini],options);[m,n]=size(Y);
  xexact=(Y(m:m,1:3))';
  vexact=(Y(m:m,4:6))';
for kk=1:length(hh)
 h=hh(kk);
[x1out{kk},v1out{kk}] = LTS_RSV(h,x0_ini,v0_ini,t_beg,t_end); 
vv1out{kk}=paf(x1out{kk},v1out{kk});  vvexact=paf(xexact,vexact);
err6(kk) =norm(abs(x1out{kk}-xexact))/norm(xexact)+norm(abs(vv1out{kk}-vvexact))/norm(vvexact); 
end

global ep
ep=1/2^10; 
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
  [T,Y] = ode45(@fff,[0:t_end],[x0_ini;v0_ini],options);[m,n]=size(Y);
  xexact=(Y(m:m,1:3))';
  vexact=(Y(m:m,4:6))';
for kk=1:length(hh)
 h=hh(kk);
[x1out{kk},v1out{kk}] = LTS_RSV(h,x0_ini,v0_ini,t_beg,t_end); 
vv1out{kk}=paf(x1out{kk},v1out{kk});  vvexact=paf(xexact,vexact);
err7(kk) = norm(abs(x1out{kk}-xexact))/norm(xexact)+norm(abs(vv1out{kk}-vvexact))/norm(vvexact); 
end
%%%%%%%%% reference exact solution
global ep
ep=1/2^12; 
options = odeset('RelTol',1e-12,'AbsTol',1e-12);
  [T,Y] = ode45(@fff,[0 t_end],[x0_ini;v0_ini],options);[m,n]=size(Y);
  xexact=(Y(m:m,1:3))';
  vexact=(Y(m:m,4:6))';
for kk=1:length(hh)
 h=hh(kk);
[x1out{kk},v1out{kk}] = LTS_RSV(h,x0_ini,v0_ini,t_beg,t_end); 
vv1out{kk}=paf(x1out{kk},v1out{kk});  vvexact=paf(xexact,vexact);
err8(kk) = norm(abs(x1out{kk}-xexact))/norm(xexact)+norm(abs(vv1out{kk}-vvexact))/norm(vvexact); 
end

%%%%%%%%%% show the figure of x

figure
interval=1;
 loglog(hh(1:interval:end),err3(1:interval:end),'m-d','Markersize',8, 'LineWidth',1)
  hold on
 loglog(hh(1:interval:end),err4(1:interval:end),'r-s','Markersize',8, 'LineWidth',1)
 loglog(hh(1:interval:end),err5(1:interval:end),'g-s','Markersize',8, 'LineWidth',1)
 loglog(hh(1:interval:end),err6(1:interval:end),'b->','Markersize',8, 'LineWidth',1)
  loglog(hh(1:interval:end),err7(1:interval:end),'b-*','Markersize',8, 'LineWidth',1)
   loglog(hh(1:interval:end),err8(1:interval:end),'c-<','Markersize',8, 'LineWidth',1)
  p=1;
loglog(hh,(err3(1)*(1+1.8))/hh(1)^p.*hh.^p,'k-.', 'LineWidth',1)
grid on
xlabel('h');
ylabel('Solution error');
set(gca,'Fontsize',19)
legend({'$\varepsilon=1/2^2$','$\varepsilon=1/2^{4}$','$\varepsilon=1/2^{6}$',...
    '$\varepsilon=1/2^8$','$\varepsilon=1/2^{10}$','$\varepsilon=1/2^{12}$','order 1'},...
    'Interpreter','latex','Location','southeast');
title('LTS-RSV')
box on
xlim([5e-5 1e-2])

